function getCart() {
  return JSON.parse(localStorage.getItem('cart') || '[]');
}
function setCart(cart) {
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
}
function addToCart(name, price) {
  const cart = getCart();
  const item = cart.find(i => i.name === name);
  if (item) item.qty += 1;
  else cart.push({ name, price, qty: 1 });
  setCart(cart);
  alert('Added to cart!');
}
function updateCartCount() {
  const cart = getCart();
  const count = cart.reduce((sum, i) => sum + i.qty, 0);
  document.querySelectorAll('#cart-count').forEach(el => el.textContent = count);
}
function renderCart() {
  const cart = getCart();
  const container = document.getElementById('cart-items');
  if (!container) return;
  if (cart.length === 0) {
    container.innerHTML = '<p>Your cart is empty.</p>';
    return;
  }
  let html = '<ul>';
  let total = 0;
  cart.forEach(item => {
    html += `<li>${item.name} x${item.qty} - $${(item.price * item.qty).toFixed(2)}</li>`;
    total += item.price * item.qty;
  });
  html += `</ul><p><strong>Total: $${total.toFixed(2)}</strong></p>`;
  container.innerHTML = html;
}
function checkout() {
  alert('This is a demo checkout. Please contact us on Instagram to place your order!');
  setCart([]);
  renderCart();
}
document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();
  renderCart();
});